def climb_stairs(n):
    if n <= 2:
        return n
    
    dp = [0] * (n + 1)
    dp[1] = 1
    dp[2] = 2

    for i in range(3, n + 1):
        dp[i] = dp[i - 1] + dp[i - 2]
        
    return dp[n]

for steps in [1, 2, 3, 4, 5, 10]:
    print(f"cтупенек: {steps:2d} | cпособов поднятьтся: {climb_stairs(steps)}")