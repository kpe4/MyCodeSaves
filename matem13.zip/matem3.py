import random
import time

def bubble_sort(arr):
    n = len(arr)
    a = arr.copy()
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]
                swapped = True
        if not swapped:
            break
    return a

def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    
    return merge(left, right)

def merge(left, right):
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    result.extend(left[i:])
    result.extend(right[j:])
    return result

sizes = [1000, 2000, 4000]

print(f"{'n':<8} | {'bubble sort (сек)':<18} | {'merge sort сек':<18}")
print("-" * 50)

prev_bubble_time = None
prev_merge_time = None

for n in sizes:
    data = [random.randint(1, 100000) for _ in range(n)]
    
    start = time.time()
    bubble_sort(data)
    bubble_time = time.time() - start
    
    start = time.time()
    merge_sort(data)
    merge_time = time.time() - start
    
    print(f"{n:<8} | {bubble_time:<18.5f} | {merge_time:<18.5f}")