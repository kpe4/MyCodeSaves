def binary_search_with_counter(arr, target):
    left = 0
    right = len(arr) - 1
    steps = 0  # Счётчик шагов
    
    while left <= right:
        steps += 1
        mid = left + (right - left) // 2
        
        # Проверяем, совпадает ли элемент в середине с искомым
        if arr[mid] == target:
            return mid, steps
        # Если элемент меньше искомого, ищем в правой половине
        elif arr[mid] < target:
            left = mid + 1
        # Иначе ищем в левой половине
        else:
            right = mid - 1
            
    return -1, steps  # Если элемент не найден

# Пример отсортированного списка
my_list = [1, 3, 5, 7, 11, 15, 19, 23, 27, 31]

# Проверка для x = 23
target_1 = 23
index_1, steps_1 = binary_search_with_counter(my_list, target_1)
print(f"Число {target_1}: индекс = {index_1}, шагов = {steps_1}")

# Проверка для x = 7
target_2 = 7
index_2, steps_2 = binary_search_with_counter(my_list, target_2)
print(f"Число {target_2}: индекс = {index_2}, шагов = {steps_2}")