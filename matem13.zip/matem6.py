def greedy_coins(n, coins):
    coins = sorted(coins, reverse=True)
    result = []
    for c in coins:
        while n >= c:
            n -= c
            result.append(c)
    return result

def dp_coins(n, coins):
    dp = [float('inf')] * (n + 1)
    parent = [0] * (n + 1)
    dp[0] = 0
    
    for i in range(1, n + 1):
        for c in coins:
            if i >= c and dp[i - c] + 1 < dp[i]:
                dp[i] = dp[i - c] + 1
                parent[i] = c
                
    res = []
    curr = n
    while curr > 0:
        c = parent[curr]
        res.append(c)
        curr -= c
    return res

coins = {1, 3, 4}
suboptimal_sums = []

print(f"{'Сумма':<6} | {'Жадный алгоритм':<20} | {'Динамическое программирование'}")
print("-" * 65)

for n in range(1, 21):
    g = greedy_coins(n, coins)
    d = dp_coins(n, coins)
    
    is_suboptimal = len(g) > len(d)
    if is_suboptimal:
        suboptimal_sums.append(n)
        
    marker = " (!)" if is_suboptimal else ""
    print(f"{n:<6} | {str(g):<20} (🪙 {len(g)}) | {str(d)} (🪙 {len(d)}){marker}")

print("\nСуммы от 1 до 20, где жадность ошибается:", suboptimal_sums)