import math

def max_binary_search_steps(n):
    return math.ceil(math.log2(n))

# Проверка для ваших примеров:
print(f"для 1000 элементов {max_binary_search_steps(1000)}")
print(f"для 1,000,000 элементов {max_binary_search_steps(1000000)}")