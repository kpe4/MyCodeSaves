def max_events(intervals):
    sorted_intervals = sorted(intervals, key=lambda x: x[1])
    
    selected = []
    last_end = -1
    
    for interval in sorted_intervals:
        start, end = interval
        if start >= last_end:
            selected.append(interval)
            last_end = end
            
    return selected

events = [(1, 3), (2, 5), (3, 9), (6, 8), (5, 7), (8, 10)]
res = max_events(events)
print("Выбранные мероприятия:", res)
print("Количество:", len(res))

#проверка
def max_events_shortest(intervals):
    sorted_intervals = sorted(intervals, key=lambda x: x[1] - x[0])
    
    selected = []
    for interval in sorted_intervals:
        start, end = interval
        conflict = False
        for s, e in selected:
            if not (end <= s or start >= e):
                conflict = True
                break
        if not conflict:
            selected.append(interval)
            
    return selected